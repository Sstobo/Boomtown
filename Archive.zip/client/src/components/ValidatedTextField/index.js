import ValidatedTextField from './ValidatedTextField';

export default ValidatedTextField;
