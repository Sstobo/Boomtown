import React, {Component } from 'react';

import './styles.css';

export default class ItemCard extends Component {
    render() {
      return <div>ItemCard</div>
    }
  }