import React, {Component } from 'react';

import './styles.css';

export default class HeaderBar extends Component {
  render() {
    return <div>Header Bar</div>
  }
}