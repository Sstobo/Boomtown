import React, { Component } from 'react';
import './styles.css'


export default class Profile extends Component {
  render() {
    return <div> Profile </div>
  }
}