import ProfileContainer from './Profile';
import Profile from './Profile';

export { Profile };
export default ProfileContainer;
