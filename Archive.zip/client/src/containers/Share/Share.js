import React, { Component } from 'react';
import './styles.css'


export default class Share extends Component {
  render() {
    return <div> Share </div>
  }
}