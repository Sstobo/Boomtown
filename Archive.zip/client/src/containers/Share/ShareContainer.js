import React, { Component } from 'react';
import Share from './Share';

export default class ShareContainer extends Component {
  render() {
    return <Share />
  }
}