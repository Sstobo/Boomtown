import ShareContainer from './Share';
import Share from './Share';

export { Share };
export default ShareContainer;
