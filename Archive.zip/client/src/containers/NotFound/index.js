import NotFoundContainer from './NotFound'

export default NotFoundContainer;