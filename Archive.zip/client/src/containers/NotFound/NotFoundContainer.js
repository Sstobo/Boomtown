import React, { Component } from 'react';
import NotFound from './NotFound';

export default class NotFoundContainer extends Component {
  render() {
    return <NotFound />
  }
}