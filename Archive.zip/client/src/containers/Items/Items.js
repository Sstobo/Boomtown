import React, { Component } from 'react';
import './style.css'
let title = ""

export default class Items extends Component {

  
  render() {
    return <div> {
      this.props.items.map(item => {
       title = item.title
       
    })}
    <li> {title} </li>
    </div>
  
  }
  }