import React, { Component } from 'react';
import Items from './Items';

export default class ItemsContainer extends Component {

  constructor(props) {
    super();
   
    this.state = {
      items: [],
      users: []
    };
  }

  componentDidMount() {

    // TODO fetch json and attatch to state
    const items = fetch('http://localhost:4000/items').then( r => r.json());
    const users = fetch('http://localhost:4000/users').then( r => r.json());

    Promise.all([items, users]).then(response => {
      
      const [ itemList, userList] = response;

      // for each item in itemlist
      // loops through whenever a user.id matches an itemowner id then append all the user data to the item array

      const combined = itemList.map(item => {
          item.itemowner = userList.find(user => user.id === item.itemowner)
            return item;
      });

      this.setState({ items: combined})
      console.log(combined)
      // set the state to the new list
    });
  }

  render() {
    return <Items items={this.state.items} />
   
  }
}