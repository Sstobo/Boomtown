import ItemsContainer from './ItemsContainer';

export default ItemsContainer;
